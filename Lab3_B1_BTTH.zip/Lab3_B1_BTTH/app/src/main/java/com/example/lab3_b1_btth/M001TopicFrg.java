package com.example.lab3_b1_btth;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;

public class M001TopicFrg extends Fragment implements View.OnClickListener {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.m001_frg_topic, container, false);

        // Tìm cả 3 View
        View itemConGai = view.findViewById(R.id.item_con_gai);
        View itemCongSo = view.findViewById(R.id.item_cong_so);
        View itemHocSinh = view.findViewById(R.id.item_hoc_sinh);

        // Gán sự kiện click
        itemConGai.setOnClickListener(this);
        itemCongSo.setOnClickListener(this);
        itemHocSinh.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View v) {
        if (getActivity() == null) return;

        // Dùng ID để phân biệt xem đã click vào đâu
        int id = v.getId();
        if (id == R.id.item_con_gai) {
            ((MainActivity) getActivity()).gotoM002Screen("Con gái");
        } else if (id == R.id.item_cong_so) {
            ((MainActivity) getActivity()).gotoM002Screen("Công sở");
        } else if (id == R.id.item_hoc_sinh) {
            ((MainActivity) getActivity()).gotoM002Screen("Học sinh");
        }
    }
}