package com.example.lab3_b1_btth;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class M002StoryListFrg extends Fragment {

    private String topicName;
    private LinearLayout storyListContainer;
    private LayoutInflater inflater;

    public static M002StoryListFrg newInstance(String topicName) {
        M002StoryListFrg fragment = new M002StoryListFrg();
        Bundle args = new Bundle();
        args.putString("TOPIC_NAME", topicName);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.inflater = inflater; // Lưu lại inflater để dùng
        View view = inflater.inflate(R.layout.m002_frg_story_list, container, false);

        if (getArguments() != null) {
            topicName = getArguments().getString("TOPIC_NAME");
        }

        // --- Ánh xạ View ---
        TextView tvTopicName = view.findViewById(R.id.tv_topic_name_m002);
        ImageView ivBack = view.findViewById(R.id.iv_back_m002);
        storyListContainer = view.findViewById(R.id.story_list_container); // "Thùng chứa" rỗng

        // --- Gán dữ liệu ---
        tvTopicName.setText(topicName);

        // --- Bắt sự kiện click ---
        ivBack.setOnClickListener(v -> {
            if (getActivity() != null) {
                getActivity().getOnBackPressedDispatcher().onBackPressed();
            }
        });

        // Tải các truyện dựa trên tên chủ đề
        loadStories();

        return view;
    }

    /**
     * Tự động thêm truyện dựa trên topicName
     */
    private void loadStories() {
        storyListContainer.removeAllViews(); // Xóa hết truyện cũ (nếu có)

        if (topicName.equals("Con gái")) {
            addStoryItem("Việc học", "Lúc bé, nghỉ học là chuyện lớn. Lớn lên mới biết...");
            addStoryItem("Đã hai lần rồi", "Một cô gái xinh đẹp về ra mắt nhà người yêu...");
            addStoryItem("Cũng như nhau", "Vợ hỏi chồng: 'Anh yêu, anh thấy em và mặt trăng...'");
        } else if (topicName.equals("Công sở")) {
            addStoryItem("Chuyện sếp", "Sếp nói với nhân viên mới: 'Ở đây chúng ta làm việc như gia đình'.");
            addStoryItem("Tăng lương", "Nhân viên: 'Sếp ơi, em muốn tăng lương'. Sếp: 'Em muốn là một chuyện...'");
            addStoryItem("Họp", "Họp là khi nhiều người nói, chẳng ai nghe, và cuối cùng mọi người đồng ý...");
        } else if (topicName.equals("Học sinh")) {
            addStoryItem("Thi cử", "Giám thị: 'Em chép bài của bạn bên cạnh à?'. Trò: 'Dạ đâu, em xem bạn ấy chép...'");
            addStoryItem("Hỏi bài", "Bạn: 'Bài này làm sao?'. Tôi: 'Tao cũng không biết'. Bạn: 'OK, vậy tao làm thế này...'");
        }
    }

    /**
     * Hàm này tạo ra 1 mục truyện (từ file item_story.xml) và thêm vào "thùng chứa"
     */
    private void addStoryItem(String title, String content) {
        // 1. Lấy layout mẫu
        View storyItemView = inflater.inflate(R.layout.item_story, storyListContainer, false);

        // 2. Tìm TextView bên trong
        TextView tvTitle = storyItemView.findViewById(R.id.tv_story_title_item);
        tvTitle.setText(title);

        // 3. Gán sự kiện click
        storyItemView.setOnClickListener(v -> {
            if (getActivity() != null) {
                ((MainActivity) getActivity()).gotoM003Screen(topicName, title, content);
            }
        });

        // 4. Thêm vào "thùng chứa"
        storyListContainer.addView(storyItemView);

        // 5. Thêm 1 đường kẻ phân cách (cho đẹp)
        View divider = new View(getContext());
        divider.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 1 // Rộng match_parent, cao 1dp
        ));
        divider.setBackgroundColor(0xFFE0E0E0); // Màu xám nhạt
        storyListContainer.addView(divider);
    }
}