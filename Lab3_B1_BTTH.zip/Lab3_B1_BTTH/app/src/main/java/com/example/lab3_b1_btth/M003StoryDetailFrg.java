package com.example.lab3_b1_btth; // Nhớ kiểm tra package
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class M003StoryDetailFrg extends Fragment {

    public static M003StoryDetailFrg newInstance(String topicName, String storyTitle, String storyContent) {
        M003StoryDetailFrg fragment = new M003StoryDetailFrg();
        Bundle args = new Bundle();
        args.putString("TOPIC_NAME", topicName);
        args.putString("STORY_TITLE", storyTitle);
        args.putString("STORY_CONTENT", storyContent);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.m003_frg_story_detail, container, false);

        String topicName = getArguments().getString("TOPIC_NAME");
        String storyTitle = getArguments().getString("STORY_TITLE");
        String storyContent = getArguments().getString("STORY_CONTENT");

        // Ánh xạ View
        TextView tvTopicName = view.findViewById(R.id.tv_topic_name_m003);
        TextView tvStoryTitle = view.findViewById(R.id.tv_story_title_m003);
        TextView tvStoryContent = view.findViewById(R.id.tv_story_content_m003);
        ImageView ivBack = view.findViewById(R.id.iv_back_m003);

        // Gán dữ liệu lên View
        tvTopicName.setText(topicName);
        tvStoryTitle.setText(storyTitle);
        tvStoryContent.setText(storyContent);

        // Bắt sự kiện click
        ivBack.setOnClickListener(v -> {
            if (getActivity() != null) {
                // Quay lại màn hình trước (M002)
                getActivity().getOnBackPressedDispatcher().onBackPressed();
            }
        });

        return view;
    }
}