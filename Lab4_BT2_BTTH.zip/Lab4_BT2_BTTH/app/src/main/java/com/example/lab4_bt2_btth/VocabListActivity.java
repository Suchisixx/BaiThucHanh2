package com.example.lab4_bt2_btth;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.HashMap;

public class VocabListActivity extends AppCompatActivity {

    private ListView lvVocab;
    // Dùng HashMap để lưu dữ liệu từ vựng
    private HashMap<Integer, String[]> vocabData = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vocab_list);

        // Chuẩn bị dữ liệu (bạn nên thêm đủ 11 chủ đề)
        prepareData();

        lvVocab = findViewById(R.id.lv_vocab);

        // Nhận index chủ đề được gửi từ MainActivity
        int topicIndex = getIntent().getIntExtra("TOPIC_INDEX", 0);

        // Lấy danh sách từ vựng tương ứng
        String[] data = vocabData.getOrDefault(topicIndex, new String[]{"(Không có dữ liệu)"});

        // Tạo Adapter đơn giản để hiển thị
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1, // Layout có sẵn của Android
                data
        );

        lvVocab.setAdapter(adapter);
    }

    // Hàm chuẩn bị dữ liệu (ví dụ)
    private void prepareData() {
        vocabData.put(0, new String[]{"Hello", "Thank you", "Goodbye", "Yes", "No"}); // Essentials
        vocabData.put(1, new String[]{"Plane", "Train", "Ticket", "Airport", "Station"}); // Traveling
        vocabData.put(2, new String[]{"Help", "Doctor", "Hospital", "Police", "Pharmacy"}); // Medical
        vocabData.put(3, new String[]{"Room", "Key", "Reservation", "Check-in", "Check-out"}); // Hotel
        // ... (Thêm dữ liệu cho các index khác) ...
    }
}