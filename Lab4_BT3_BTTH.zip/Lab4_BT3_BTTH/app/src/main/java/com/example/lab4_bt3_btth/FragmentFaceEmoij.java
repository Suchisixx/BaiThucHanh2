package com.example.lab4_bt3_btth;

import static android.icu.lang.UCharacter.GraphemeClusterBreak.V;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button; // Thêm import
import android.widget.ImageView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import java.util.Random; // Thêm import

public class FragmentFaceEmoij extends Fragment implements View.OnClickListener {

    // Mảng 9 ID của 9 ImageView trong layout
    private static final int[] ids = {
            R.id.iv_face1, R.id.iv_face2, R.id.iv_face3,
            R.id.iv_face4, R.id.iv_face5, R.id.iv_face6,
            R.id.iv_face7, R.id.iv_face8, R.id.iv_face9
    };

    // === PHẦN THAY ĐỔI THEO YÊU CẦU CỦA BẠN ===
    // "Bể" icon của bạn (gồm 6 icon bạn có)
    private static final int[] MY_EMOJIS = {
            R.drawable.ic_angry,
            R.drawable.ic_beauty,
            R.drawable.ic_boss,
            R.drawable.ic_choler,
            R.drawable.ic_dribble,
            R.drawable.ic_look_down
    };

    private ImageView[] imageViews = new ImageView[9]; // Mảng lưu 9 ImageView
    private Button btnRandomize; // Nút random
    private Random random = new Random(); // Đối tượng để random
    // === KẾT THÚC PHẦN THAY ĐỔI ===

    private Context mContext;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.m001_frg_face_emoij, container, false);
        initViews(rootView);
        return rootView;
    }

    @Override
    public void onAttach(Context context) {
        mContext = context;
        super.onAttach(context);
    }

    private void initViews(View v) {
        // Ánh xạ 9 ImageView và lưu vào mảng
        for (int i = 0; i < ids.length; i++) {
            imageViews[i] = v.findViewById(ids[i]);
            imageViews[i].setOnClickListener(this); // Gán click cho từng emoji
        }

        // Ánh xạ nút Random và gán click
        btnRandomize = v.findViewById(R.id.btn_randomize);
        btnRandomize.setOnClickListener(this); // Gán click cho nút Random

        // Random lần đầu khi mở Fragment
        randomizeEmojis();
    }

    @Override
    public void onClick(View v) {
        // Kiểm tra xem có phải nút random được click không
        if (v.getId() == R.id.btn_randomize) {
            randomizeEmojis(); // Nếu đúng, gọi hàm random
        } else {
            // Nếu không phải, thì đó là 1 emoji -> hiển thị toast
            ImageView ivFace = (ImageView) v;
            showToast(ivFace.getDrawable());
        }
    }

    // === HÀM RANDOM ĐÃ SỬA ĐỔI (Bài tập 3) ===
    private void randomizeEmojis() {
        // Lặp qua 9 ô ImageView
        for (int i = 0; i < imageViews.length; i++) {
            // Lấy 1 vị trí ngẫu nhiên từ "bể" 6 icon (từ 0 đến 5)
            int randomIndex = random.nextInt(MY_EMOJIS.length); // MY_EMOJIS.length là 6

            // Lấy ID của icon ngẫu nhiên đó
            int randomEmojiId = MY_EMOJIS[randomIndex];

            // Gán icon đó cho ImageView thứ i
            imageViews[i].setImageResource(randomEmojiId);
        }
    }

    // Hàm showToast giữ nguyên như trong PDF [cite: 680-686]
    private void showToast(Drawable drawable) {
        Toast toast = new Toast(mContext);
        ImageView ivEmoij = new ImageView(mContext);
        ivEmoij.setImageDrawable(drawable);
        toast.setView(ivEmoij);
        toast.show();
    }
}
