package com.example.lab3_b2_btth;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    TextView tvVietnamese, tvEnglish, tvFrench;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Loadlocale
        loadLocale();
        // --------------------------------------------------

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Đặt tiêu đề cho Action Bar (nếu có)
        // Dòng này có thể gây lỗi nếu bạn dùng NoActionBar, có thể xóa đi
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(R.string.app_name);
        }

        // Ánh xạ các view
        tvVietnamese = findViewById(R.id.tvVietnamese);
        tvEnglish = findViewById(R.id.tvEnglish);
        tvFrench = findViewById(R.id.tvFrench);

        // Gán sự kiện click
        tvVietnamese.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeLanguage("vi");
            }
        });

        tvEnglish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeLanguage("en");
            }
        });

        tvFrench.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeLanguage("fr");
            }
        });
    }

    /**
     * Phương thức này dùng để thay đổi ngôn ngữ
     * @param langCode Mã ngôn ngữ (ví dụ: "vi", "en", "fr")
     */
    private void changeLanguage(String langCode) {
        // 1. Lưu ngôn ngữ người dùng chọn vào SharedPreferences
        SharedPreferences.Editor editor = getSharedPreferences("Settings", MODE_PRIVATE).edit();
        editor.putString("My_Lang", langCode);
        editor.apply();

        // 2. Tải lại Activity để áp dụng thay đổi
        // (Cách đơn giản và hiệu quả nhất)
        recreate();
    }

    /**
     * Phương thức này dùng để tải ngôn ngữ đã lưu và áp dụng
     * PHẢI được gọi trước super.onCreate() và setContentView()
     */
    private void loadLocale() {
        SharedPreferences prefs = getSharedPreferences("Settings", MODE_PRIVATE);
        String language = prefs.getString("My_Lang", ""); // Lấy ngôn ngữ đã lưu, "" là mặc định

        if (!language.isEmpty()) {
            updateAppLocale(language);
        }
    }

    /**
     * Cập nhật cấu hình ứng dụng với Locale (ngôn ngữ) mới
     * @param langCode Mã ngôn ngữ
     */
    private void updateAppLocale(String langCode) {
        Locale locale = new Locale(langCode);
        Locale.setDefault(locale);

        Resources res = getResources();
        Configuration config = res.getConfiguration();
        config.setLocale(locale);

        // Cập nhật cấu hình cho resources
        res.updateConfiguration(config, res.getDisplayMetrics());
    }
}