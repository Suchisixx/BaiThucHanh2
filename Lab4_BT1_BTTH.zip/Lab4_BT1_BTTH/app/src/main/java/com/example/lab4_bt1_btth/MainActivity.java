package com.example.lab4_bt1_btth;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Khai báo các View cần tương tác
    private EditText etEmail;
    private EditText etPassword;
    private TextView tvLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Không dùng EdgeToEdge.enable(this);

        // 1. Sửa lại để dùng đúng layout của Bài tập 1
        setContentView(R.layout.m001_act_login);

        // 2. Xóa code ViewCompat.setOnApplyWindowInsetsListener...
        // vì layout của bạn không có ID R.id.main

        // 3. Thêm logic cho Bài tập 1

        // Ánh xạ View từ layout
        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        tvLogin = findViewById(R.id.tv_login);

        // Gán sự kiện click cho nút Login
        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Lấy nội dung từ EditText
                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();

                // Gọi hàm hiển thị custom toast
                showCustomToast(email, password);
            }
        });
    }

    /**
     * Hàm hiển thị Custom Toast theo yêu cầu Bài tập 1 [cite: 716]
     */
    private void showCustomToast(String email, String password) {
        // Inflate layout custom toast
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.layout_custom_toast, null); // Dùng null

        // Set nội dung cho TextView bên trong custom toast
        TextView text = layout.findViewById(R.id.tv_toast_message);
        text.setText("Bạn đã đăng nhập thành công với email: " + email + " và mật khẩu: " + password);

        // Tạo và hiển thị Toast
        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(layout);
        toast.show();
    }
}
